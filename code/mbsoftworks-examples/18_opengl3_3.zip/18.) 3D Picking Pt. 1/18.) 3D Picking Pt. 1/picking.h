#pragma once

glm::vec4 GetColorByIndex(int index);
int GetIndexByColor(int r, int g, int b);
int GetPickedColorIndexUnderMouse();