#pragma once

glm::vec4 GetColorByIndex(int index);
int GetIndexByColor(int r, int g, int b);
int GetPickedColorIndexUnderMouse();

void Get3DRayUnderMouse(glm::vec3* v1, glm::vec3* v2);
bool RaySphereCollision(glm::vec3 vSphereCenter, float fSphereRadius, glm::vec3 vA, glm::vec3 vB);